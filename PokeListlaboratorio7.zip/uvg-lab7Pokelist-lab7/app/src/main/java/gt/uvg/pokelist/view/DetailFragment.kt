package gt.uvg.pokelist.view

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.navArgs
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.squareup.picasso.Picasso
import gt.uvg.pokelist.databinding.FragmentDetailBinding
import gt.uvg.pokelist.model.Pokemon

class DetailFragment : Fragment() {
    val arg: DetailFragmentArgs by navArgs()
    private lateinit var recyclerView: RecyclerView //recycler view
    private var _binding: FragmentDetailBinding? = null
    private val binding get() = _binding!!
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {//Aqui es para mostrar las imagenes
        _binding = FragmentDetailBinding.inflate(inflater, container, false)
        return binding.root
    }
    //Aqui es para colocar todas las imagenes y remplazar las imagenes determinadas
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        val Pokerin = Pokemon (arg.pokemonId, "unknown")
        Picasso.get().load(Pokerin.imageUrlFront).into(binding.imageView2)
        Picasso.get().load(Pokerin.imageUrlBack).into(binding.imageView3)
        Picasso.get().load(Pokerin.imageUrlShinnyBack).into(binding.imageView5)
        Picasso.get().load(Pokerin.imageUrlShinnyFront).into(binding.imageView4)
    }
    //Aqui mira si se esta viendo o no, si no va a quitar el binding de la pantalla
    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

}