package gt.uvg.pokelist.view

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.navigation.findNavController
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.RecyclerView
import com.squareup.picasso.Picasso
import gt.uvg.pokelist.databinding.ItemPokemonViewBinding
import gt.uvg.pokelist.model.Pokemon

class PokemonListAdapter(private val pokemonList: List<Pokemon>) : RecyclerView.Adapter<PokemonListAdapter.PokemonListHolder>() {

    inner class PokemonListHolder(val binding: ItemPokemonViewBinding) : RecyclerView.ViewHolder(binding.root){ //subclase de pokemon para el binding
        var name = binding.pokemonName ;
        var foto = binding.pokemonPhoto;
    }
    //Aqui es para crear los olders de los pokemones
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PokemonListHolder {
        val binding = ItemPokemonViewBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return PokemonListHolder(binding)
    }
    //Aqui se le asigna cada propiedad a cada uno de los pokemones que corresponde
    override fun onBindViewHolder(holder: PokemonListHolder, position: Int) {
        val item = pokemonList.get(position)
        holder.name.text = item.name;
        Picasso.get().load(item.imageUrlFront).into(holder.foto)
        holder.itemView.setOnClickListener {
            val action =//Aqui se va usar la vista de la fuente y lo va navegar al fragmento seleccionado
                MainFragmentDirections.actionMainFragmentToDetailFragment(pokemonList.get(position).id)
            holder.binding.root.findNavController()
                .navigate(action)
        }
    }
    //aqui va regresar el tamaño del lineal en la pantalla
    override fun getItemCount(): Int {
        // TODO
        return pokemonList.size
    }


}