package gt.uvg.pokelist.view

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import gt.uvg.pokelist.databinding.FragmentMainBinding
import gt.uvg.pokelist.repository.PokemonRepository

//fragmento principal donde se muestra la lista de los pokemons
class MainFragment: Fragment() {
    private var _binding: FragmentMainBinding? = null
    private val binding get() = _binding!!
    private lateinit var recyclerView: RecyclerView


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }
    //Aqui se alarga el fragmento de los pokemones
    override fun onCreateView(
        longers: LayoutInflater, conter: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflar el fragmento
        _binding = FragmentMainBinding.inflate(longers, conter, false)
        return binding.root
    }
    //Aqui crea el lenear con todos los pokemones
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val pokemonList = PokemonRepository().getPokemonList()
        recyclerView = binding.recyclerView
        recyclerView.layoutManager = LinearLayoutManager(context)
        recyclerView.adapter = PokemonListAdapter(pokemonList)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}